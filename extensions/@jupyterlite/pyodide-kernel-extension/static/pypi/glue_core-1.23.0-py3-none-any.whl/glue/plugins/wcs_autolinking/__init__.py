def setup():
    from . import wcs_autolinking  # noqa
