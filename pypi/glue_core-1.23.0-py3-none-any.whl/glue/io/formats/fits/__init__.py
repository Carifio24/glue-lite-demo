# Data factories are already defined in glue.core.data_factories, but they will
# be moved here in future.


def setup():
    from . import subset_mask  # noqa
