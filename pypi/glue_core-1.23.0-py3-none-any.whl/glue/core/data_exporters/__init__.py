def setup():
    from . import gridded_fits  # noqa
    from . import astropy_table  # noqa
    from . import hdf5  # noqa
