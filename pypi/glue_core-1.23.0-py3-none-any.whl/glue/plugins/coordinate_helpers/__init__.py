def setup():
    from . import link_helpers  # noqa
