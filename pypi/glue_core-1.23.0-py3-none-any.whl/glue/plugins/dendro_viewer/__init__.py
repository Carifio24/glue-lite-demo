def setup():
    from .data_factory import load_dendro  # noqa
