
"""Declare any extra link functions like this"""
# @link_function(info='translates A to B', output_labels=['b'])
# def a_to_b(a):
#    return a * 3


"""Data factories take a filename as input and return a Data object"""
# @data_factory('JPEG Image')
# def jpeg_reader(file_name):
#    ...
#    return data
