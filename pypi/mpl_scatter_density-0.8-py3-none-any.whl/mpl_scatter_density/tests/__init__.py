import os

baseline_root = 'baseline'
baseline_subdir = '3.0.x'

baseline_dir = os.path.join(baseline_root, baseline_subdir)
