import warnings
from echo import *
warnings.warn('glue.external.echo is deprecated, import from echo directly instead')
