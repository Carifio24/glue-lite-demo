"""
Modules in this directory smooth over importing functionality that may be
present in different libraries, depending on the users' system.
"""
